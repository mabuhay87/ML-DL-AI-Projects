using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RetailDemandForecasting.Pages;

public class IndexModel : PageModel
{
    public void OnGet() { }
}
